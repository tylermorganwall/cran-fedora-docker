# libdeflate 1.23.1

* Fixed CMake detection on CRAN macOS servers
* Added a `NEWS.md` file to track changes to the package.
