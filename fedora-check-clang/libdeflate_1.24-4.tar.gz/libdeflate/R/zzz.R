#' @useDynLib libdeflate, .registration = TRUE
NULL
